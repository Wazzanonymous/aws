# OPA example

This folder contains example [Open Policy Agent (OPA)](https://www.openpolicyagent.org/) policy that enforces all 
resources include a specific tag.

For more info, please see Chapter 9, "How to test Terraform code", of
*[Terraform: Up and Running](http://www.terraformupandrunning.com)*.

## Quick start

Please see the README in the companion Terraform module at 
[09-testing-terraform-code/examples/opa](../../terraform/09-testing-terraform-code/examples/opa) for instructions on 
how to use this policy to test that module.

